module.exports = {
    url: 'mongodb+srv://shubhamsainim47:fU42RTS5NQHsZGqv@cluster0.nefwncl.mongodb.net/'
}